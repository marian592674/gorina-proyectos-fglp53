@echo off
REM Colector Gorina — una corrida (genera/actualiza datos.json)
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Python no esta instalado. Instalar desde https://www.python.org/downloads/
  echo         y marcar "Add Python to PATH" al instalar.
  exit /b 1
)
python colector.py
exit /b %errorlevel%