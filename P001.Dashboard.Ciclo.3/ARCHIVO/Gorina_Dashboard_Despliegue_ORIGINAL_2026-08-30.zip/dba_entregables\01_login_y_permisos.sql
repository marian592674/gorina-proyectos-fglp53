/* =========================================================================
   GORINA · Ciclo 3 · INTEGRACIÓN CON BASES DE DATOS
   Archivo: 01_login_y_permisos.sql
   Uso:     Ejecutar UNA VEZ en CADA SQL Server (TRV y ALMACÉN), con permisos de sysadmin.
   Objetivo: crear un LOGIN de SOLO LECTURA para el dashboard + mapear usuario
             y conceder SELECT sobre las vistas vw_tablero_* (que se crean en 02/03).

   IMPORTANTE: este login SOLO lee. NO se le otorgan permisos de escritura,
   DDL ni acceso a otras tablas/objetos de producción.
   ========================================================================= */

/* 1) Ponerle el password que el equipo de datos definirá (mínimo 12 caracteres).
      @@CAMBIAR_PASSWORD@@  */
DECLARE @pwd nvarchar(128) = N'@@CAMBIAR_PASSWORD@@';

/* 2) Los dos servidores (TRV y ALMACÉN) usarán el mismo login para simplificar. */
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'tablero_ro')
  CREATE LOGIN [tablero_ro] WITH PASSWORD = @pwd, CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;

/* 3) Mapear a la base de datos donde viven las vistas. */
/*    @@NOMBRE_BD@@ = nombre de la BD productiva (p. ej. Gorina_TRV o Gorina_Almacen) */
DECLARE @db sysname = N'@@NOMBRE_BD@@';
IF db_id(@db) IS NOT NULL AND NOT EXISTS (SELECT 1 FROM sys.database_principals AS p WHERE p.name = N'tablero_ro' AND p.type = 'S')
BEGIN
  DECLARE @sql nvarchar(4000) = N'USE ' + QUOTENAME(@db) + N'; CREATE USER [tablero_ro] FOR LOGIN [tablero_ro];';
  EXEC sp_executesql @sql;
END

/* 4) Conceder solo SELECT sobre las vistas del tablero. */
/*    (Las vistas se crean en los archivos 02_vistas_trv.sql y 03_vista_almacen.sql) */
USE @@NOMBRE_BD@@;
GRANT SELECT ON [dbo].[vw_tablero_trv1]      TO [tablero_ro];
GRANT SELECT ON [dbo].[vw_tablero_trv2]      TO [tablero_ro];
/* En el servidor ALMACÉN se ejecuta igual pero con: */
GRANT SELECT ON [dbo].[vw_tablero_almacen]   TO [tablero_ro];

/* Sugerencia: verificar lecturas con una cuenta con permisos DBA antes de liberar:
   SELECT TOP 10 * FROM dbo.vw_tablero_trv1;

   NOTA DE SEGURIDAD: no exponer el password del login en el HTML ni en archivos
   públicos. El password vive solo en config.json del colector (fuera del sitio IIS). */