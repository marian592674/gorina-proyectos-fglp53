@echo off
setlocal EnableDelayedExpansion
title Gorina Ciclo3 - Validador
color 0F

:: valida_dashboard.bat - Windows 10 Pro - Gorina Ciclo 3
:: Valida punto a punto. Doble clic derecho > Ejecutar como administrador.
:: Si se cierra rapido, ejecutar desde cmd: valida_dashboard.bat > log.txt 2>&1

set "SITE_PATH=C:\Ciclo3\Servicios\dashboard"
set "COLECTOR_PATH=C:\Ciclo3\Servicios\colector"
set "SITE_NAME=Gorina Ciclo3"
set "ERR=0"
set "WARN=0"
set "LOG=%~dp0valida_log.txt"

echo Validador Gorina Ciclo3 - %date% %time% > "%LOG%"
echo ================================================= >> "%LOG%"

echo.
echo ============================================================
echo   GORINA CICLO 3 - VALIDADOR PUNTO A PUNTO (Win10 Pro)
echo   Ejecutar como ADMINISTRADOR para validacion completa
echo ============================================================
echo.
echo   Log se guarda en: %LOG%
echo.

:: Chequeo admin
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [AVISO] No estas como Administrador. Algunos checks se saltaran. >> "%LOG%"
  echo [AVISO] No estas como Administrador. Algunos checks se saltaran.
  echo         Click derecho ^> Ejecutar como administrador
  echo.
  set /a WARN+=1
) else (
  echo [OK] Ejecutando como Administrador >> "%LOG%"
  echo [OK] Ejecutando como Administrador
)

call :SECTION "1. CARPETAS"
call :CHECK_DIR "%SITE_PATH%" "Sitio IIS"
call :CHECK_DIR "%COLECTOR_PATH%" "Colector"

call :SECTION "2. ARCHIVOS DEL SITIO (dashboard)"
call :CHECK_FILE "%SITE_PATH%\dashboard_operaciones.html" "HTML dashboard"
call :CHECK_FILE "%SITE_PATH%\datos.json" "datos.json"
call :CHECK_FILE "%SITE_PATH%\web.config" "web.config (MIME .json)"
if exist "%SITE_PATH%\datos.json" (
  echo   -- Validando JSON...
  echo   -- Validando JSON... >> "%LOG%"
  powershell -NoProfile -Command "try { $j=Get-Content -Raw '%SITE_PATH%\datos.json' | ConvertFrom-Json; if ($j.trv -ne $null -and $j.crane -ne $null) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
  if !errorlevel! equ 0 ( call :OK "  datos.json tiene claves trv/crane" ) else ( call :FAIL "  datos.json JSON invalido o sin claves trv/crane" )
  for %%F in ("%SITE_PATH%\datos.json") do echo   Tamano: %%~zF bytes & echo   Tamano: %%~zF bytes >> "%LOG%"
)

call :SECTION "3. ARCHIVOS DEL COLECTOR"
call :CHECK_FILE "%COLECTOR_PATH%\colector.py" "colector.py"
call :CHECK_FILE "%COLECTOR_PATH%\config.json" "config.json"
call :CHECK_FILE "%COLECTOR_PATH%\colector.bat" "colector.bat"
if exist "%COLECTOR_PATH%\config.json" (
  findstr /C:"C:/Ciclo3/Servicios/dashboard/datos.json" "%COLECTOR_PATH%\config.json" >nul 2>&1
  if !errorlevel! equ 0 ( call :OK "  config.json out_path OK" ) else ( call :FAIL "  config.json out_path NO apunta a C:/Ciclo3/Servicios/dashboard/datos.json" )
)

call :SECTION "4. PYTHON"
where python >nul 2>&1
if %errorlevel% equ 0 (
  for /f "delims=" %%v in ('python --version 2^>^&1') do set PYV=%%v
  call :OK "  Python: !PYV!"
) else (
  call :FAIL "  Python NO encontrado en PATH. Instalar Python 3.12 con Add to PATH"
)

call :SECTION "5. IIS (Windows 10 Pro)"
sc query W3SVC >nul 2>&1
if %errorlevel% equ 0 (
  sc query W3SVC | findstr /I "RUNNING" >nul 2>&1
  if !errorlevel! equ 0 ( call :OK "  Servicio IIS (W3SVC) corriendo" ) else ( call :FAIL "  Servicio IIS DETENIDO. Ejecutar: net start W3SVC" )
) else (
  call :FAIL "  IIS NO instalado. Panel ^> Activar caracteristicas ^> IIS"
  goto :SKIP_IIS
)

set APPCMD=%windir%\System32\inetsrv\appcmd.exe
if exist "%APPCMD%" (
  "%APPCMD%" list site /name:"%SITE_NAME%" >nul 2>&1
  if !errorlevel! equ 0 (
    call :OK "  Sitio IIS '%SITE_NAME%' existe"
    echo   Bindings: >> "%LOG%"
    "%APPCMD%" list site /name:"%SITE_NAME%" /text:bindings >> "%LOG%" 2>&1
    "%APPCMD%" list site /name:"%SITE_NAME%" /text:bindings
    echo   PhysicalPath: >> "%LOG%"
    "%APPCMD%" list vdir /app.name:"%SITE_NAME%/" /text:physicalPath >> "%LOG%" 2>&1
    "%APPCMD%" list vdir /app.name:"%SITE_NAME%/" /text:physicalPath
  ) else (
    call :FAIL "  Sitio '%SITE_NAME%' NO existe. Ejecutar instala_iis_dashboard.bat como Admin"
  )
) else (
  echo [INFO] appcmd no encontrado, salto check sitio
  echo [INFO] appcmd no encontrado >> "%LOG%"
)

:SKIP_IIS

call :SECTION "6. COLECTOR - PRUEBA --test"
if exist "%COLECTOR_PATH%\colector.py" (
  echo   Ejecutando: python colector.py --test ...
  echo   Ejecutando: python colector.py --test ... >> "%LOG%"
  pushd "%COLECTOR_PATH%"
  python colector.py --test >> "%LOG%" 2>&1
  if !errorlevel! equ 0 ( call :OK "  colector --test OK" ) else ( call :FAIL "  colector --test fallo. Ver logs/colector.log" )
  popd
  if exist "%COLECTOR_PATH%\logs\colector.log" (
    echo   --- Ultimas 5 lineas de logs/colector.log --- >> "%LOG%"
    powershell -NoProfile -Command "Get-Content '%COLECTOR_PATH%\logs\colector.log' -Tail 5" >> "%LOG%" 2>&1
    powershell -NoProfile -Command "Get-Content '%COLECTOR_PATH%\logs\colector.log' -Tail 5"
  )
)

call :SECTION "7. HTTP LOCALHOST"
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -Uri 'http://localhost/datos.json' -UseBasicParsing -TimeoutSec 5; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 (
  call :OK "  http://localhost/datos.json responde 200"
) else (
  powershell -NoProfile -Command "try { $r=Invoke-WebRequest -Uri 'http://localhost/dashboard_operaciones.html' -UseBasicParsing -TimeoutSec 5; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
  if !errorlevel! equ 0 (
    call :OK "  http://localhost/dashboard_operaciones.html OK pero /datos.json fallo - revisar web.config"
  ) else (
    call :FAIL "  http://localhost NO responde. Verificar sitio IIS en :80:"
  )
)

call :SECTION "8. FIREWALL PUERTO 80"
netsh advfirewall firewall show rule name="Dashboard Gorina" >nul 2>&1
if %errorlevel% equ 0 ( call :OK "  Regla firewall 'Dashboard Gorina' existe" ) else ( echo [INFO] Regla 'Dashboard Gorina' no existe - crear si hace falta >> "%LOG%" & echo [INFO] Regla 'Dashboard Gorina' no existe )

call :SECTION "9. TASK SCHEDULER"
schtasks /Query /TN "Gorina - Colector datos" >nul 2>&1
if %errorlevel% equ 0 (
  call :OK "  Tarea 'Gorina - Colector datos' existe"
  schtasks /Query /TN "Gorina - Colector datos" /V /FO LIST | findstr /I "Estado" >> "%LOG%" 2>&1
) else (
  echo [INFO] Tarea 'Gorina - Colector datos' NO existe >> "%LOG%"
  echo [INFO] Tarea 'Gorina - Colector datos' NO existe - ejecutar instala_tarea_colector.bat
)

call :SECTION "10. IP DE ESTA VM (para que otros entren)"
echo   IPs detectadas: >> "%LOG%"
ipconfig | findstr /I "IPv4" >> "%LOG%" 2>&1
ipconfig | findstr /I "IPv4"
echo.
echo   --- Prueba rapida desde esta VM: http://localhost/dashboard_operaciones.html ---
echo   --- Desde tu PC/LAN usa la IPv4 de arriba: http://IP_VM/dashboard_operaciones.html ---
echo   --- Desde tu PC/LAN usa la IPv4 de arriba: http://IP_VM/dashboard_operaciones.html --- >> "%LOG%"

echo.
echo ============================================================
if %ERR% equ 0 (
  echo   RESULTADO: TODO OK (%WARN% avisos)
) else (
  echo   RESULTADO: %ERR% ERRORES / %WARN% avisos - Revisar [FAIL] arriba
)
echo ============================================================
echo   Log completo: %LOG%
echo.

:: Copiar log tambien a dashboard para verlo por HTTP si hace falta
copy /Y "%LOG%" "%SITE_PATH%\valida_log.txt" >nul 2>&1

echo Presiona cualquier tecla para cerrar...
pause >nul
exit /b %ERR%

:SECTION
echo.
echo -- %~1 ----------------------------------------
echo. >> "%LOG%"
echo -- %~1 ---------------------------------------- >> "%LOG%"
exit /b

:CHECK_DIR
if exist "%~1" ( call :OK "  %~2 : %~1" ) else ( call :FAIL "  %~2 NO existe: %~1" )
exit /b

:CHECK_FILE
if exist "%~1" ( call :OK "  %~2 : %~1" ) else ( call :FAIL "  %~2 NO existe: %~1" )
exit /b

:OK
echo [ OK ] %~1
echo [ OK ] %~1 >> "%LOG%"
exit /b

:FAIL
echo [FAIL] %~1
echo [FAIL] %~1 >> "%LOG%"
set /a ERR+=1
exit /b
