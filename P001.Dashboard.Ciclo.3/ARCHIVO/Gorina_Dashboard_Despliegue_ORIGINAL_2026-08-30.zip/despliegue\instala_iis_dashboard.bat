@echo off
setlocal EnableDelayedExpansion
title Gorina Ciclo3 - Instalar Sitio IIS
color 0F

:: instala_iis_dashboard.bat - Windows 10 Pro
:: Ejecutar COMO ADMINISTRADOR. Click derecho > Ejecutar como administrador.
:: Log en instala_iis_log.txt

set "SITE_NAME=Gorina Ciclo3"
set "SITE_PATH=C:\Ciclo3\Servicios\dashboard"
set "APPCMD=%windir%\System32\inetsrv\appcmd.exe"
set "LOG=%~dp0instala_iis_log.txt"

echo Instalador IIS - %date% %time% > "%LOG%"

echo.
echo ============================================================
echo   GORINA CICLO 3 - INSTALADOR SITIO IIS (Win10 Pro)
echo   Ejecutar COMO ADMINISTRADOR
echo ============================================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [FAIL] No estas como Administrador. >> "%LOG%"
  echo [FAIL] No estas como Administrador.
  echo Click derecho sobre este .bat ^> Ejecutar como administrador
  pause
  exit /b 1
)

sc query W3SVC >nul 2>&1
if %errorlevel% neq 0 (
  echo [FAIL] IIS no instalado. >> "%LOG%"
  echo [FAIL] IIS no esta instalado.
  echo Para instalar: Panel de control ^> Programas ^> Activar caracteristicas ^> IIS
  echo Comando: DISM /Online /Enable-Feature /FeatureName:IIS-WebServerRole
  pause
  exit /b 1
)
echo [OK] IIS detectado. >> "%LOG%"
echo [OK] IIS detectado.

sc query W3SVC | findstr /I "RUNNING" >nul 2>&1
if %errorlevel% neq 0 (
  echo [INFO] Iniciando W3SVC... >> "%LOG%"
  echo [INFO] Iniciando W3SVC...
  net start W3SVC >> "%LOG%" 2>&1
)

if not exist "%SITE_PATH%" mkdir "%SITE_PATH%" 2>nul

if not exist "%SITE_PATH%\dashboard_operaciones.html" (
  echo [FAIL] Falta dashboard_operaciones.html en %SITE_PATH% >> "%LOG%"
  echo [FAIL] Falta %SITE_PATH%\dashboard_operaciones.html - copiar desde ZIP tablero_v4
  pause
  exit /b 1
)
if not exist "%SITE_PATH%\web.config" (
  echo [INFO] Creando web.config >> "%LOG%"
  echo [INFO] Creando web.config
  echo ^<?xml version="1.0" encoding="UTF-8"?^> > "%SITE_PATH%\web.config"
  echo ^<configuration^> >> "%SITE_PATH%\web.config"
  echo   ^<system.webServer^> >> "%SITE_PATH%\web.config"
  echo     ^<staticContent^> >> "%SITE_PATH%\web.config"
  echo       ^<mimeMap fileExtension=".json" mimeType="application/json" /^> >> "%SITE_PATH%\web.config"
  echo     ^</staticContent^> >> "%SITE_PATH%\web.config"
  echo   ^</system.webServer^> >> "%SITE_PATH%\web.config"
  echo ^</configuration^> >> "%SITE_PATH%\web.config"
)

if not exist "%APPCMD%" (
  echo [FAIL] appcmd no encontrado >> "%LOG%"
  echo [FAIL] No se encontro %APPCMD%
  pause
  exit /b 1
)

"%APPCMD%" list site "Default Web Site" >nul 2>&1
if %errorlevel% equ 0 (
  "%APPCMD%" list site "Default Web Site" /text:bindings | findstr ":80:" >nul 2>&1
  if %errorlevel% equ 0 (
    echo [INFO] Default Web Site ocupa :80 - lo detengo >> "%LOG%"
    echo [INFO] Default Web Site ocupa :80 - lo detengo
    "%APPCMD%" stop site "Default Web Site" >> "%LOG%" 2>&1
  )
)

"%APPCMD%" list site /name:"%SITE_NAME%" >nul 2>&1
if %errorlevel% equ 0 (
  echo [INFO] Sitio ya existe - actualizando >> "%LOG%"
  echo [INFO] Sitio ya existe - actualizando
  "%APPCMD%" set site /site.name:"%SITE_NAME%" /[path='/'].physicalPath:"%SITE_PATH%" >> "%LOG%" 2>&1
  "%APPCMD%" set site /site.name:"%SITE_NAME%" /bindings:"http/*:80:" >> "%LOG%" 2>&1
) else (
  echo [INFO] Creando sitio %SITE_NAME% >> "%LOG%"
  echo [INFO] Creando sitio %SITE_NAME%...
  "%APPCMD%" add site /name:"%SITE_NAME%" /bindings:"http/*:80:" /physicalPath:"%SITE_PATH%" >> "%LOG%" 2>&1
  if !errorlevel! neq 0 (
    echo [FAIL] No se pudo crear sitio. Ver puerto 80 ocupado. >> "%LOG%"
    "%APPCMD%" list site >> "%LOG%" 2>&1
    "%APPCMD%" list site
    pause
    exit /b 1
  )
)
"%APPCMD%" list apppool /name:"%SITE_NAME%" >nul 2>&1
if %errorlevel% neq 0 (
  "%APPCMD%" add apppool /name:"%SITE_NAME%" >> "%LOG%" 2>&1
  "%APPCMD%" set site /site.name:"%SITE_NAME%" /applicationDefaults.applicationPool:"%SITE_NAME%" >> "%LOG%" 2>&1
)
"%APPCMD%" start site /site.name:"%SITE_NAME%" >> "%LOG%" 2>&1
echo [OK] Sitio %SITE_NAME% en %SITE_PATH% puerto 80 >> "%LOG%"
echo [OK] Sitio %SITE_NAME% creado en %SITE_PATH% puerto 80

echo [INFO] Creando regla firewall >> "%LOG%"
netsh advfirewall firewall delete rule name="Dashboard Gorina" >nul 2>&1
netsh advfirewall firewall add rule name="Dashboard Gorina" dir=in action=allow protocol=TCP localport=80 >> "%LOG%" 2>&1

echo.
echo [INFO] Probando http://localhost/dashboard_operaciones.html ...
powershell -NoProfile -Command "Start-Sleep 2; try { $r=Invoke-WebRequest -Uri 'http://localhost/dashboard_operaciones.html' -UseBasicParsing -TimeoutSec 5; Write-Host ('  -> HTTP ' + $r.StatusCode + ' OK'); exit 0 } catch { Write-Host ('  -> FAIL: ' + $_.Exception.Message); exit 1 }"
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -Uri 'http://localhost/datos.json' -UseBasicParsing -TimeoutSec 5; Write-Host ('  -> datos.json ' + $r.StatusCode + ' ' + $r.Content.Length + ' bytes'); exit 0 } catch { Write-Host ('  -> datos.json FAIL: ' + $_.Exception.Message); exit 1 }"

echo.
echo ============================================================
echo   INSTALACION IIS TERMINADA
echo   Probar: http://localhost/dashboard_operaciones.html
ipconfig | findstr /I "IPv4"
echo   Desde tu PC/LAN: http://IP_VM/dashboard_operaciones.html
echo ============================================================
echo Log: %LOG%
pause
exit /b 0
