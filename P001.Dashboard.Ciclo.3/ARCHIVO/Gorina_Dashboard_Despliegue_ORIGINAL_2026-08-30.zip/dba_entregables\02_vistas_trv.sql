/* =========================================================================
   GORINA · Ciclo 3 · INTEGRACIÓN — VISTAS DEL SERVIDOR TRV
   Archivo: 02_vistas_trv.sql   (se ejecuta en el SQL Server de TRV)
   Objetivo: exponer dos vistas que devuelvan por DÍA, para el dashboard:
             fecha · ingresos · salidas · ocupacion

   CONTRATO (lo que el colector espera):
     - fecha:      tipo fecha/datetime (el colector normaliza a dd/mm/yyyy).
     - ingresos:   número (cajas). NULL si no aplica.
     - salidas:    número (cajas). NULL si no aplica.
     - ocupacion:  PORCENTAJE 0-100 (p. ej. 73.04 = 73,04%). Si la fuente lo da
                   como fracción (0.7304), multiplicar por 100 en la consulta.
                   (El colector igualmente convierte a % si le llega <= 1.)
   ========================================================================= */

-- -------------------------------------------------------------------------
-- VISTA TRV1 — adaptar el SELECT a la tabla/columnas reales de producción.
-- @@TABLA_TRV1@@  = tabla de TRV1 (o vista) · @@FECHA@@, @@ING@@, @@SAL@@, @@OCUPA@@
-- -------------------------------------------------------------------------
CREATE OR ALTER VIEW [dbo].[vw_tablero_trv1] AS
SELECT
    CONVERT(date, @@FECHA@@)                     AS fecha,
    CONVERT(decimal(12,0), ISNULL(@@ING@@, 0))   AS ingresos,
    CONVERT(decimal(12,0), ISNULL(@@SAL@@, 0))   AS salidas,
    -- Ocupación. Si en la fuente es fracción (0.73): * 100
    CONVERT(decimal(10,4), ISNULL(@@OCUPA@@, 0)) * 
        CASE WHEN @@OCUPA@@ <= 1 AND @@OCUPA@@ >= 0 THEN 100 ELSE 1 END AS ocupacion
FROM @@TABLA_TRV1@@
WHERE @@FECHA@@ IS NOT NULL;

-- -------------------------------------------------------------------------
-- VISTA TRV2 — ídem para TRV2 (hoy SIN operación: puede devolver 0 filas).
-- Si TRV2 todavía no tiene fuente, dejar este archivo sin ejecutar y avisar:
-- el colector TRV2 quedará vacío (válido).
-- -------------------------------------------------------------------------
CREATE OR ALTER VIEW [dbo].[vw_tablero_trv2] AS
SELECT
    CONVERT(date, @@FECHA@@)                     AS fecha,
    CONVERT(decimal(12,0), ISNULL(@@ING@@, 0))   AS ingresos,
    CONVERT(decimal(12,0), ISNULL(@@SAL@@, 0))   AS salidas,
    CONVERT(decimal(10,4), ISNULL(@@OCUPA@@, 0)) *
        CASE WHEN @@OCUPA@@ <= 1 AND @@OCUPA@@ >= 0 THEN 100 ELSE 1 END AS ocupacion
FROM @@TABLA_TRV2@@
WHERE @@FECHA@@ IS NOT NULL;