# Guía de despliegue — VM central (Gorina Ciclo 3)

Puesta en producción del tablero autónomo: servido por **IIS en una VM central
(no productiva)** y alimentado por el **colector**. Acceso: LAN / Wi-Fi del
teléfono / VPN cuando se está fuera de la oficina.

> Regla de oro: **nada se instala ni se modifica en las VMs productivas**
> (TRV y Almacén). Esas solo prestan una vista y un login de solo lectura.

## 0. VM central (requisitos)
- Windows Server (2016/2019/2022) o Windows 10/11 Pro, **siempre encendida**.
- En la **misma red** que las VMs productivas (que pueda alcanzar 1433).
- Acceso a internet para: descarga de Python/ODBC y, en Etapa 1, leer Google Sheets.
- (Opcional, recomendado) el firewall interno permite el puerto del sitio (80) desde la LAN.

## 1. Instalar componentes en la VM central
1. **IIS**: Server Manager → Agregar roles → Servidor web (IIS) → incluye
   "Características HTTP comunes". (En Windows Pro: Panel → Windows Features → IIS.)
2. **Python 3.12**: descargar de python.org → instalar marcando **"Add Python to PATH"**.
3. **ODBC Driver (solo Etapa 2)**: Microsoft ODBC Driver 18 (o 17) for SQL Server,
   y `pip install pyodbc` en la terminal.

## 2. Montar la carpeta del sitio (configuración de esta instalación)
```
C:\Ciclo3\Servicios\dashboard\          ← SITIO IIS (Physical Path)
   ├── dashboard_operaciones.html       ← copia de integrador_bds/tablero_v4/
   ├── datos.json                       ← lo escribe el colector (config apunta acá)
   └── web.config                       ← MIME .json (incluido)

C:\Ciclo3\Servicios\colector\           ← COLECTOR (FUERA del sitio, no expuesto por HTTP)
   ├── colector.py
   ├── config.json  (out_path = C:/Ciclo3/Servicios/dashboard/datos.json)
   ├── colector.bat
   └── logs/
```
> IMPORTANTE: `colector/` va **al lado** de `dashboard/`, NO dentro. Si lo metés dentro de `dashboard/` quedaría expuesto por HTTP (http://IP/colector/config.json) y expondría el password de la BD. Así, bajo `Servicios/`, queda ordenado pero a salvo.

## 3. Crear el sitio en IIS
1. `inetmgr` → Sitios → **Agregar sitio web...** (no usar Default Web Site).
   * Nombre del sitio: `Gorina Ciclo3`
   * Ruta física: `C:\Ciclo3\Servicios\dashboard`
   * Enlaces: `http` · puerto `80` · IP `*` / `Todas las no asignadas` · Nombre de host vacío.
   * Copiar `web.config` (ya incluido en el ZIP) a `C:\Ciclo3\Servicios\dashboard\web.config` — asegura MIME `.json`:
    ```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <configuration>
      <system.webServer>
        <staticContent>
          <mimeMap fileExtension=".json" mimeType="application/json" />
        </staticContent>
      </system.webServer>
    </configuration>
    ```
2. Abrir el puerto 80 en el firewall del SO hacia la LAN:
    `netsh advfirewall firewall add rule name="Dashboard Gorina" dir=in action=allow protocol=TCP localport=80`

## 4. Conectar el colector
1. Copiar la carpeta `integrador_bds/colector/` a `C:\Ciclo3\Servicios\colector\` (hermana de `dashboard/`, no hija).
2. Ya viene con `out_path = "C:/Ciclo3/Servicios/dashboard/datos.json"` — no tocar salvo que cambies la ruta del sitio.
3. Correr una vez `python colector.py` y verificar que `datos.json` aparece.
4. Configurar el **Task Scheduler** (ver `colector/LEEME_Colector.md`) cada 5 min.

## 5. Publicar y acceder
| Desde | Cómo |
|---|---|
| **PC en la LAN** | `http://IP_VM_CENTRAL/dashboard/` (favorito / acceso directo en escritorio) |
| **Celular (misma Wi-Fi)** | La misma URL en el navegador del teléfono (Chrome/Safari) |
| **Externo (fuera de la oficina)** | Conectarse a la **VPN corporativa** → abrir la misma URL interna |

> El tablero sigue siendo "el mismo HTML": no hay app ni instalación del lado del
> cliente. Te das de alta el "Descargar informe" (PDF) y el auto-refresco v4.

## 6. Etapa 2 — conectar las BDs (cuando el DBA entregue)
1. Entregar `dba_entregables/` al DBA (login `tablero_ro` + vistas adaptadas).
2. En `config.json` del colector: completar `sql.servers` (IPs, BD, password) y
   verificar los `views`; luego `source: "sql"`.
3. Probar `python colector.py` → el histórico acumulado se mantiene y desde
   entonces la fuente son las vistas SQL. **Google Sheets queda fuera del flujo.**
4. (Opcional, futuro) envio automático por mail del PDF — ver PLAN_INTEGRACION.

## Seguridad
- El password de la BD vive solo en `C:\Ciclo3\Servicios\colector\config.json` (fuera de `dashboard/`, no servido por IIS).
- No exponer el sitio a internet abierta: solo LAN/Wi-Fi + VPN.
- Revisar periodicamente `logs/colector.log` (1 minuto) y que la tarea sigue activa.