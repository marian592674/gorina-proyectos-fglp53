# Integración BDs — Tablero Gorina Ciclo 3 (sub-proyecto autonômo)

Documento de trabajo de la versión autónoma del dashboard: el tablero dejará de
depender del Google Sheet alimentado a mano y se nutrirá de las **bases de datos
productivas** (SQL Server) a través de un **colector**.

- **Carpeta**: `integrador_bds/` — sub-proyecto independiente para no mezclar con
  la versión vigente. La versión actual (raíz `dashboard_operaciones.html`) **sigue
  funcionando con Google Sheets** hasta que esta se valide y se decida el corte.
- **Regla**: el tablero original, sus KPIs, gráficos e informes **no se tocan**.
  Cualquier cambio futuro vive en la copia `tablero_v4/`.

## Objetivos
1. Obtener los datos **solo** (autonomía, sin cargado manual).
2. Refresco automático cada pocos minutos (día en curso).
3. Conservar el **histórico** (sembrado desde el sheet + acumulación diaria).
4. Servir el tablero por la red (LAN, celular y VPN externa).
5. (Futuro, opcional) envío automático del informe por mail.

## Decisiones tomadas
| Tema | Decisión |
|---|---|
| Fuente | 2 SQL Server productivos (TRV y Alm. Congelado/Almacén), **solo lectura** |
| Acceso a producción | Login `tablero_ro` + vistas `vw_tablero_*` que crea el **DBA** (no se toca nada más) |
| Google Sheets | Queda fuera del flujo en Etapa 2; se usa temporalmente en Etapa 1 |
| Colector | Python en una **VM central no productiva**, cada 1–5 min (Task Scheduler) |
| Servido | **IIS** en la misma VM central, mismo origen (sin CORS) |
| Acceso desde afuera | **VPN corporativa** (nada expuesto a internet) |
| Histórico | `datos.json` **acumula** (sembrar opcional + upsert diario; no se borra) |

## Arquitectura
```
[ SQL Server TRV ]──┐  (vistas vw_tablero_trv1/trv2, login tablero_ro)
[ SQL Server Alm. ]─┤  (vista vw_tablero_almacen, login tablero_ro)
                    ▼
        [ VM CENTRAL ]
           • colector.py (Sheet en Etapa 1 → SQL en Etapa 2) c/ 5 min
           • IIS: dashboard_operaciones.html (v4) + datos.json
                    ▼
        LAN  http://IP/dashboard/   ·  celular Wi-Fi  ·  VPN
```

## Contrato de datos (`datos.json`)
```json
{
  "trv":   [ { "k": "2026-08-18", "inn": 5214, "out": 4982, "occ": 73.04 }, ... ],
  "trv2":  [],
  "crane": [ { "k": "2026-08-18", "inn": 145, "out": 132, "occ": 18.61 }, ... ]
}
```
- `k` en `YYYY-MM-DD`; `inn`/`out` numéricos o `null`; `occ` **porcentaje 0–100**.
- El tablero v4 deriva la `date` desde `k`; si `occ` llega `<=1` lo pasa a % (robustez).

## Estructura de `integrador_bds/`
```
integrador_bds/
  PLAN_INTEGRACION.md        ← este documento (versiones + hoja de ruta)
  dba_entregables/           ← scripts SQL para el DBA + lectura para el DBA
  colector/                  ← colector.py + config.json + colector.bat + LEEME
  tablero_v4/                ← copia del dashboard (loader datos.json + auto-refresh) + datos.json
  despliegue/                ← guía IIS + checklist de validación
```

## Hojas de ruta PASO A PASO (desde cero)

### Fase A — Preparar (hoy, en la PC local) ✅ lista
1. [x] Carpeta `integrador_bds/` con todo el material.
2. [x] `dba_entregables/` (login + 3 vistas + lectura DBA) para coordinar con el DBA.
3. [x] `colector/` Etapa 1 (fuente Sheet) + `config.json` + `.bat` + Logica de upsert.
4. [x] `tablero_v4/` (copia con `loadFromJSON()` + auto-refresco 5 min) + `datos.json` de muestra.
5. [x] Validación headless del tablero v4 (usa `datos.json`, KPIs/tabs OK).
6. [x] Guía de despliegue IIS + checklist.

### Fase B — Encender lo nuevo en la VM central (cuando se decida)
7. [ ] Pedir/crear la **VM central** (no productiva, siempre encendida, misma red).
8. [ ] Instalar **IIS**, **Python 3.12** (Add to PATH) y dejar la carpeta `colector/` en lugar fijo.
9. [ ] Crear el sitio IIS → `C:\inetpub\wwwroot\dashboard\` (ver `despliegue/GUIA_DESPLIEGUE.md`), MIME `.json`, firewall 80.
10. [ ] Copiar `tablero_v4/` → carpeta del sitio; apuntar `config.json` (`out_path`) al sitio.
11. [ ] Correr `python colector.py` una vez y verificar `datos.json` + `logs/colector.log`.
12. [ ] Crear la tarea de **Task Scheduler** cada 5 minutos (revisar LEEME_Colector).
13. [ ] Validar checklist de `despliegue/CHECKLIST_VALIDACION.md` (PC LAN + celular + VPN después).

### Fase C — conectar las BDs (Etapa 2)
14. [ ] Entregar **`dba_entregables/`** al DBA: login `tablero_ro` (RO) y las 3 vistas adaptadas a sus tablas.
15. [ ] Confirmar puerto **1433** desde la VM central a ambas VMs productivas.
16. [ ] En `config.json`: completar `sql.servers` (IPs, BD, password) y pasar `source: "sql"`.
17. [ ] `pip install pyodbc` + instalar **ODBC Driver 18** en la VM central.
18. [ ] Recorrobar `python colector.py` leyendo de las vistas; **histórico acumulado se mantiene**.
19. [ ] Confirmar en **checklist E**: sin Google Sheets en el flujo (verificar red).

### Fase D — corte y futuros
20. [ ] Decidir fecha de corte: el sitio IIS apunta a `tablero_v4/` (ya es) y el tablero
      de la raíz queda como referencia/legado en `old/`.
21. [ ] (Opcional futuro) **mail automático** del informe PDF vía SMTP desde el colector.
22. [ ] (Opcional futuro) si se requieren consultas/auditoría SQL: subir a una **tabla
      intermedia** (SQL Express VM central) o un historial más rico — hoy no hace falta.

## Versiones del sub-proyecto
| Fecha | Versión | Descripción | Estado |
|---|---|---|---|
| 2026-08-15 | 1.0 | Preparación completa en PC local: dba_entregables v1, colector v1 (source=sheet), tablero_v4 (loader JSON + auto-refresh), guía IIS + checklist. Validado headless. | ✅ listo |
| — | 1.1 | Despliegue en VM central + Task Scheduler. | ⏳ al desplegar |
| — | 2.0 | Colector v2 (source=sql) con vistas del DBA; Google Sheets fuera del flujo. | ⏳ al conectar BDs |
| — | 3.0 | (futuro) mail automático del informe. | — |

## Plan sencillo de mantenimiento (updates / reparaciones / trabajos)
Siempre **antes** de tocar algo: copiar el archivo a `old/` (o `integrador_bds/backups/`) y
registrar aquí la versión. Regla: los cambios de KPIs/informes NO van al tablero v4.

| Tipo de trabajo | Dónde | Procedimiento |
|---|---|---|
| **Ajustar KPIs/informes** | `tablero_v4/dashboard_operaciones.html` (copia) | Aplicar el cambio en la copia, validar headless, actualizar versión acá. NUNCA en la raíz hasta decidir corte. |
| **Ajustar el cargado** (frecuencia, fuente, mapeo) | `colector/config.json` y `colector.py` | Cambiar + `python colector.py --test` + revisar log + versión acá. |
| **Nueva BD/sistema** | `config.json` (`layout`/`sql.views`) + (si hace falta) vista en el DBA | Agregar entrada, `--test`, validar tabep del tablero. |
| **Histórico** | `datos.json` (nunca editar a mano) | El colector upserta; si se quiere re-sembrar, regenerar desde fuente y re-correr. Backup manual previo a cualquier operación rara. |
| **Caída de sistema fuente** | `logs/colector.log` | El colector avisa; conserva el último dato bueno. Revisar tarea programada y red/1433. |
| **Reparar tablero tras cambio malo** | Git de `old/` + puntos de control | Revertir de `old/version3/*.html` (versiones del plan original) o de `integrador_bds/backups/`. |
| **Actualizar librerías CDN** (chart.js/jspdf) | Local + headless | Probar con `--dump-dom`; los CDN son compatibles (los dispositivos tienen internet). |
| **Enviar por mail** (futuro) | `colector.py` + un módulo `mail.py` | Generar el PDF existente y enviarlo por SMTP; sin tocar KPIs/informes del tablero. |

**Conexión de partida para futuros trabajos**
- El tablero v4 consume únicamente `datos.json` (mismo origen). Todo el pipeline de datos
  pasa por `colector.py` → `config.json` → vistas SQL.
- Documentación de referencia raíz: `PLAN_PROYECTO.md` (historial original) — solo se le
  agrega una sección que apunta acá.