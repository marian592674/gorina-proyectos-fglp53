# Lectura para el DBA — vistas del dashboard Gorina Ciclo 3

Este paquete pide **solo lectura** sobre las bases productivas de TRV y de Alm.
Congelado. No se modifica ningún objeto de producción: se crea un **login de solo
lectura** y **3 vistas** (`vw_tablero_*`) que aíslan lo que el dashboard consume.

## Entregables

| Archivo | Servidor | Qué crea |
|---|---|---|
| `01_login_y_permisos.sql` | TRV **y** ALMACÉN | Login `tablero_ro` (RO) + user + `GRANT SELECT` sobre las vistas |
| `02_vistas_trv.sql` | TRV | `vw_tablero_trv1` y `vw_tablero_trv2` |
| `03_vista_almacen.sql` | ALMACÉN | `vw_tablero_almacen` |

## Contrato de las vistas (lo que el colector espera)

Cada vista devuelve **una fila por día**, con 4 columnas en este orden:

| Columna | Tipo esperado | Ejemplo |
|---|---|---|
| `fecha` | date/datetime | 2026-08-18 |
| `ingresos` | número (decimal) | 5214 |
| `salidas` | número (decimal) | 4982 |
| `ocupacion` | **% 0–100** (decimal) | 73.04 |

Reglas importantes:
- **`ocupacion`**: se pide porcentaje **0–100**. Si la fuente la guarda como
  fracción (0.73), multiplicar por 100 en la vista (los scripts ya traen el
  `CASE` preparado). El colector igualmente autocorrige: si recibe un valor
  `<= 1` lo trata como fracción y lo pasa a %.
- Pueden venir días con `ingresos`/`salidas` en NULL (p. ej. TRV sin salidas
  algunos días); es válido.
- **TRV2 hoy no tiene operación**: si todavía no hay tabla fuente, no ejecutar
  la vista `vw_tablero_trv2` y avisar; ese sistema quedará vacío en el tablero
  (comportamiento actual).

## Pasos sugeridos
1. Completar los placeholders `@@...@@` de los 3 scripts con los nombres reales
   (tablas, columnas, nombre de BD) de cada servidor.
2. Evaluar las 2 vistas con una cuenta con permisos antes de liberarlas:
   ```sql
   SELECT TOP 20 * FROM dbo.vw_tablero_trv1 ORDER BY fecha DESC;
   SELECT TOP 20 * FROM dbo.vw_tablero_almacen ORDER BY fecha DESC;
   ```
3. Ejecutar `01_login_y_permisos.sql` en ambos servidores (definir un password
   **solo para este login**, mínimo 12 caracteres).
4. Probar una conexión con el login `tablero_ro` y `SELECT` sobre las vistas
   **desde la VM central** (misma red, puerto 1433).

## Seguridad
- El login es estrictamente de **lectura** sobre las vistas; sin permisos sobre
  otras tablas ni DDL/escritura.
- El password NO va en el tablero ni en archivos del sitio IIS: vive únicamente
  en `config.json` del colector, fuera de la carpeta pública.
- Confirmar que la VM central alcanza el puerto **1433** de ambas VMs
  (firewall/misma red de trabajo).