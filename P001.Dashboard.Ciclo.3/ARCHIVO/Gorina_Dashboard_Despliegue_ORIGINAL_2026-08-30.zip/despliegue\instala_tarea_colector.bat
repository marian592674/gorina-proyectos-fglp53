@echo off
setlocal
title Gorina Ciclo3 - Instalar Tarea Colector
color 0F

set "COLECTOR_PATH=C:\Ciclo3\Servicios\colector"
set "TASK_NAME=Gorina - Colector datos"
set "LOG=%~dp0instala_tarea_log.txt"

echo Instalador Tarea - %date% %time% > "%LOG%"

echo.
echo ============================================================
echo   GORINA CICLO 3 - INSTALAR TAREA COLECTOR (cada 5 min)
echo ============================================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [FAIL] No estas como Administrador. >> "%LOG%"
  echo [FAIL] No estas como Administrador. Click derecho ^> Ejecutar como administrador
  pause & exit /b 1
)

if not exist "%COLECTOR_PATH%\colector.bat" (
  echo [FAIL] No se encontro %COLECTOR_PATH%\colector.bat >> "%LOG%"
  echo [FAIL] No se encontro %COLECTOR_PATH%\colector.bat
  pause & exit /b 1
)

schtasks /Query /TN "%TASK_NAME%" >nul 2>&1
if %errorlevel% equ 0 (
  echo [INFO] Tarea existente - la reemplazo >> "%LOG%"
  schtasks /Delete /TN "%TASK_NAME%" /F >> "%LOG%" 2>&1
)

echo [INFO] Creando tarea cada 5 minutos... >> "%LOG%"
echo [INFO] Creando tarea cada 5 minutos...
schtasks /Create /TN "%TASK_NAME%" /TR "\"%COLECTOR_PATH%\colector.bat\"" /SC MINUTE /MO 5 /ST 00:00 /RU SYSTEM /F >> "%LOG%" 2>&1
if %errorlevel% equ 0 (
  echo [OK] Tarea creada con schtasks >> "%LOG%"
  echo [OK] Tarea creada
  goto :config_more
) else (
  echo [INFO] Probando via PowerShell... >> "%LOG%"
  powershell -NoProfile -Command "$act=New-ScheduledTaskAction -Execute '%COLECTOR_PATH%\colector.bat' -WorkingDirectory '%COLECTOR_PATH%'; $tr=New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration ([TimeSpan]::MaxValue); $pr=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; $set=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2); Register-ScheduledTask -TaskName '%TASK_NAME%' -Action $act -Trigger $tr -Principal $pr -Settings $set -Force | Out-Null; exit $LASTEXITCODE" >> "%LOG%" 2>&1
  if %errorlevel% equ 0 (
    echo [OK] Tarea creada via PowerShell >> "%LOG%"
    echo [OK] Tarea creada via PowerShell
  ) else (
    echo [FAIL] No se pudo crear tarea >> "%LOG%"
    echo [FAIL] No se pudo crear tarea. Ver taskschd.msc
    pause & exit /b 1
  )
)

:config_more
powershell -NoProfile -Command "$t=Get-ScheduledTask -TaskName '%TASK_NAME%'; $t.Settings.AllowStartIfOnBatteries=$true; $t.Settings.DontStopIfGoingOnBatteries=$true; $t.Settings.StartWhenAvailable=$true; $t.Settings.ExecutionTimeLimit='PT2H'; Set-ScheduledTask -InputObject $t | Out-Null" >> "%LOG%" 2>&1

echo [INFO] Ejecutando tarea una vez para probar... >> "%LOG%"
echo [INFO] Ejecutando tarea una vez...
schtasks /Run /TN "%TASK_NAME%" >> "%LOG%" 2>&1
timeout /t 4 >nul
if exist "%COLECTOR_PATH%\logs\colector.log" (
  echo [OK] Log generado: >> "%LOG%"
  powershell -NoProfile -Command "Get-Content '%COLECTOR_PATH%\logs\colector.log' -Tail 5" >> "%LOG%" 2>&1
  powershell -NoProfile -Command "Get-Content '%COLECTOR_PATH%\logs\colector.log' -Tail 5"
) else (
  echo [INFO] Aun no hay log - esperar 5 min >> "%LOG%"
  echo [INFO] Aun no hay log - esperar 5 min
)

echo.
echo ============================================================
echo   TAREA INSTALADA
echo   Ver en: taskschd.msc
echo   Forzar: schtasks /Run /TN "Gorina - Colector datos"
echo ============================================================
echo Log: %LOG%
pause
exit /b 0
