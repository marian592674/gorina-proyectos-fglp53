# Checklist de validación — tablero v4 + colector

> Marcar cada ítem antes de dar el despliegue por bueno. Al final queda una
> versión del despliegue registrada en `PLAN_INTEGRACION.md`.

## A. Datos / colector
- [ ] `python colector.py` corre sin errores (Etapa 1: fuente Sheet).
- [ ] `datos.json` existe y es válido:
  - [ ] Claves `trv`, `trv2`, `crane`.
  - [ ] Cada registro: `k` en `YYYY-MM-DD`, `inn`/`out` numéricos (o null), `occ` en % (0-100).
  - [ ] TRV2 puede ser `[]` (sin operación, válido).
- [ ] Se ve la copia previa `datos.json.prev` (segundo corrida en adelante).
- [ ] `logs/colector.log` registra conteos por sistema.

## B. Tablero v4 (validación headless recomendada)
Probar con Chrome headless contra el sitio/`http.server`:
```
chrome --headless=new --dump-dom --virtual-time-budget=15000 http://host/dashboard/dashboard_operaciones.html
```
- [ ] `#loadStatus` termina en "Actualizado HH:MMhs" (sin "Actualizando…" eterno).
- [ ] `#rangeLabel` muestra período y fechas con datos.
- [ ] Pestañas: TRV1 · TRV2 · TRV1+TRV2 · Alm. Congelado.
- [ ] `#kpiRow` (Ingresos/día, Salidas/día, Máx ingreso, Espacio libre) con valores.
- [ ] Gráficos de Ocupación e Ingresos/Salidas dibujados.
- [ ] Botón **Descargar informe** genera el PDF (JPEG) sin errores.
- [ ] Auto-refresco: esperar >5 min (o bajar `AUTO_REFRESH_MS`) y ver que reaparece "Actualizado".

## C. Fallbacks
- [ ] Si se borra `datos.json`: el tablero cae al Google Sheet (CSV→JSONP) sin romperse.
- [ ] Si un sistema llega vacío (TRV2): se muestra "SIN OPERACIÓN" como hoy.

## D. Despliegue IIS
- [ ] URL `http://IP_VM_CENTRAL/dashboard/` responde desde un PC de la LAN.
- [ ] `datos.json` se sirve con MIME `application/json`.
- [ ] Se consulta desde un **celular en la misma Wi-Fi**.
- [ ] Desde afuera (casa): conectarse a la **VPN** y abrir la misma URL.
- [ ] La tarea del Task Scheduler corre cada 5 min (revisar log de la tarea).

## E. Etapa 2 (BDs) — cuando existan las vistas
- [ ] Login `tablero_ro` + vistas confirmadas por el DBA (SELECT OK desde la VM).
- [ ] `config.json` con `source: "sql"` y las 2 conexiones (TRV y ALMACÉN) OK.
- [ ] `python colector.py` lee de las vistas; el histórico acumulado se mantiene.
- [ ] Google Sheets deja de ser consultado (verificar con la red/apagando el sheet no rompe).