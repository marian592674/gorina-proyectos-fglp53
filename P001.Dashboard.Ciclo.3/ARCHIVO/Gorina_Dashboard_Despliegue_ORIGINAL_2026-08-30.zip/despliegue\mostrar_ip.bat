@echo off
title Gorina - Mostrar IP
ipconfig | findstr /I "IPv4"
echo.
echo Prueba en esta VM: http://localhost/dashboard_operaciones.html
echo Desde tu PC/LAN: http://IP-DE-ARRIBA/dashboard_operaciones.html
echo.
pause
