/* =========================================================================
   GORINA · Ciclo 3 · INTEGRACIÓN — VISTA DEL SERVIDOR ALMACÉN
   Archivo: 03_vista_almacen.sql   (se ejecuta en el SQL Server de Alm. Congelado)
   Objetivo: vista por DÍA para el dashboard:
             fecha · ingresos · salidas · ocupacion
   Mismo contrato que las vistas TRV (fecha / ingresos / salidas / ocupacion 0-100).
   ========================================================================= */

-- @@TABLA_ALM@@ = tabla real (o vista) · @@FECHA@@, @@ING@@ (palets), @@SAL@@, @@OCUPA@@
CREATE OR ALTER VIEW [dbo].[vw_tablero_almacen] AS
SELECT
    CONVERT(date, @@FECHA@@)                     AS fecha,
    CONVERT(decimal(12,0), ISNULL(@@ING@@, 0))   AS ingresos,
    CONVERT(decimal(12,0), ISNULL(@@SAL@@, 0))   AS salidas,
    -- Ocupación en %. Si llega como fracción (0.18), pasarla a 0-100.
    CONVERT(decimal(10,4), ISNULL(@@OCUPA@@, 0)) *
        CASE WHEN @@OCUPA@@ <= 1 AND @@OCUPA@@ >= 0 THEN 100 ELSE 1 END AS ocupacion
FROM @@TABLA_ALM@@
WHERE @@FECHA@@ IS NOT NULL;